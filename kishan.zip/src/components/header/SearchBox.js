
function Searchbox() {
    return(
        <div className="search-box">
            <input type="text" name="search" className="search" placeholder="Search in library..." />
        </div>
    )
}

export default Searchbox;